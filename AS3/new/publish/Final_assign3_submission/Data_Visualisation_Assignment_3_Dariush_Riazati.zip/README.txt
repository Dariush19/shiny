﻿List of files
=======================
- Assign_3_data_wrangle_version_1.ipynb    Data wrangling run in Jupyter notebook
		- Input csv files to data wrangling
				- time_series_covid19_confirmed_global.csv
				- time_series_covid19_deaths_global.csv
				- time_series_covid19_recovered_global.csv
		- Output of the data wrangling and input to R data visualization

- Assign3_dariush_v2.Rmd                   Data visualisation. R Markdown run from RStudio
- Data Exploration Report.pdf              The actual report

Link to the web app
https://dariush.shinyapps.io/assign3_dariush_v2/

Youtube link
https://youtu.be/OGMmdAhp3Cc